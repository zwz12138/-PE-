#include<Windows.h>
#include <stdio.h>
DWORD LoadFile(const char* fileName, LPVOID* ppfBuffer);//�����ļ�
void showPEheader(const char* fileName);//show PEͷ
void showSection(const char* fileName);//show ��
PIMAGE_NT_HEADERS FileToNtHeader(LPVOID pFileBuffer);//��λNTͷ
LPVOID ImageBufferToFileBuffer(LPVOID pImageBuffer);//��ImageBufferתΪFileBuffer
LPVOID FileBufferToImageBuffer(LPVOID pFileBuffer);//��FileBufferתΪImageBuffer
PIMAGE_SECTION_HEADER LocateSectionBase(LPVOID pFileBuffer);//��λ��һ���ڵĵ�ַ
void SaveFile(LPVOID pFileBuffer, const char* str, DWORD FileSize);//�����ļ�
LPVOID changeimagebuffer(LPVOID imagebuffer);//�հ��������������
LPVOID NEWSetion(LPVOID pImageBuffer);//�����ڲ������Ӵ���
DWORD FileSizeget(LPVOID pImageBuffer);//�����ļ���С

int main()
{
	const char* newFile = "TEST13.exe";
	const char* fileName = "1.exe";
	LPVOID pFileBuffer = NULL;
	showPEheader(fileName);
	DWORD FileSize = LoadFile(fileName, &pFileBuffer);
	LPVOID pImageBuffer = FileBufferToImageBuffer(pFileBuffer);
	//DWORD RVA = 0x1e01, FOA = 0;
	//FOA = RVAtoFOA(RVA, pImageBuffer);
	//printf("%x(RVA) - > %x(FOA)", RVA, FOA);

	//LPVOID pNewFileBuffer= ImageBufferToFileBuffer(pImageBuffer);

	//�¼ӽڱ�����
	LPVOID newsetion = NEWSetion(pImageBuffer);
	LPVOID pNewFileBuffer = ImageBufferToFileBuffer(newsetion);
	SaveFile(pNewFileBuffer, newFile, FileSizeget(pNewFileBuffer));


	//LPVOID changeBuffer = changeimagebuffer(pImageBuffer);

	//LPVOID pNewFileBuffer = ImageBufferToFileBuffer(changeBuffer);

	//SaveFile(pNewFileBuffer, newFile, FileSize);
	//SaveFile(pImageBuffer, newFile,FileSize);
	free(pFileBuffer);
	//free(pImageBuffer);
	//free(newsetion);
	//free(pNewFileBuffer);
	printf("end\n");






	return 0;

}