﻿#include<Windows.h>
#include <stdio.h>
DWORD LoadFile(const char* fileName, LPVOID* ppfBuffer);//加载文件
void showPEheader(const char* fileName);//show PE头
void showSection(const char* fileName);//show 节
PIMAGE_NT_HEADERS FileToNtHeader(LPVOID pFileBuffer);//定位NT头
LPVOID ImageBufferToFileBuffer(LPVOID pImageBuffer);//从ImageBuffer转为FileBuffer
LPVOID FileBufferToImageBuffer(LPVOID pFileBuffer);//从FileBuffer转为ImageBuffer
PIMAGE_SECTION_HEADER LocateSectionBase(LPVOID pFileBuffer);//定位第一个节的地址
void SaveFile(LPVOID pFileBuffer, const char* str, DWORD FileSize);//保存文件
LPVOID changeimagebuffer(LPVOID imagebuffer);//空白区添加任意代码



//#define MESSAGE_BOX_ADDRESS (DWORD)0x7DCBFD1E
#define MESSAGE_BOX_ADDRESS (DWORD)&MessageBox
//shellcode定义
BYTE shellcode[] = {
	0x6A,00,0x6A,00,0x6A,00,0x6A,00,
	0xE8,00,00,00,00,
	0xE9,00,00,00,00,
};

/*
* 函数功能：加载文件
* 参数说明：filename：文件名
* 返回值：通过malloc分配的内存的大小，若无法分配则返回0
* 使用该函数后需要调用free（）函数释放堆空间
*/
DWORD LoadFile(const char* fileName, LPVOID* ppfBuffer)
{
	FILE* fp;
	DWORD FileSize = 0;
	fopen_s(&fp, fileName, "rb");
	if (fp == NULL)
	{
		printf("cannot open %s", fileName);
		exit(EXIT_FAILURE);
	}
	fseek(fp, 0, SEEK_END);
	FileSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	*ppfBuffer = (LPVOID*)malloc(FileSize);
	if (*ppfBuffer == NULL)
	{
		printf("cannot malloc");
		return 0;
	}

	memset(*ppfBuffer, 0, FileSize);
	fread(*ppfBuffer, FileSize, 1, fp);
	if (fclose(fp) != 0)
	{
		printf("cannot close file");
		exit(EXIT_FAILURE);
	}
	return FileSize;

	/*
	* 函数功能：打印PE头信息
	* 参数说明：filename：文件名
	* 返回值：无
	*
	*/
}
void showPEheader(const char* fileName)
{
	LPVOID pFileBuffer = NULL;
	PIMAGE_DOS_HEADER pDosHeader = NULL;
	PIMAGE_NT_HEADERS pNtHeaders = NULL;
	PIMAGE_FILE_HEADER pFileHeader = NULL;
	PIMAGE_OPTIONAL_HEADER pOptionalHeader = NULL;
	PIMAGE_SECTION_HEADER pSectionHeader = NULL;

	LoadFile(fileName, &pFileBuffer);
	if (pFileBuffer == NULL)
	{
		printf("cannot open file");
		exit(EXIT_FAILURE);
	}
	//判断是否为MZ
	if (*((PWORD)pFileBuffer) != IMAGE_DOS_SIGNATURE)
	{
		printf("不是有效的MZ标志");
		free(pFileBuffer);
		return;
	}
	pDosHeader = (PIMAGE_DOS_HEADER)pFileBuffer;
	printf("***********DOS Header**********\n");
	printf("pDosHeader->e_magic	MZ 标志:%x\n", pDosHeader->e_magic);
	printf("pDosHeader->e_lfanew	PE 偏移:%x\n", pDosHeader->e_lfanew);
	//判断PE偏移是否有效
	//* (PDWORD) ptr1 = *(PDWORD)((DWORD)pFileBuffer + pDosHeader->e_lfanew);
	if (*(PDWORD)((ULONG_PTR)pFileBuffer + (pDosHeader->e_lfanew)) != IMAGE_NT_SIGNATURE)
	{
		printf("不是有效的PE标志");
		free(pFileBuffer);
		return;
	}
	pNtHeaders = (PIMAGE_NT_HEADERS)((BYTE*)pFileBuffer + pDosHeader->e_lfanew);
	printf("*********NT Header**************\n");
	printf("pNtHeaders->Signature	PE 标志 :%x\n", pNtHeaders->Signature);
	puts("*********PE Header**************");
	printf("FileHeader.Machine		CPU平台:%x\n", pNtHeaders->FileHeader.Machine);
	printf("pNtHeaders->FileHeader.NumberOfSections	PE文件中区块数量:%x\n", pNtHeaders->FileHeader.NumberOfSections);
	printf("pNtHeaders->FileHeader.Characteristics		(描述文件属性）:%x\n", pNtHeaders->FileHeader.Characteristics);
	puts("*********Optional PE Header**************");
	printf("pNtHeaders->OptionalHeader.Magic	可选PE头幻数：%x\n", pNtHeaders->OptionalHeader.Magic);
	printf("pNtHeaders->OptionalHeader.AddressOfEntryPoint		:OEP程序入口点 %x\n", pNtHeaders->OptionalHeader.AddressOfEntryPoint);
	printf("ImageBase      	:%x\n", pNtHeaders->OptionalHeader.ImageBase);






	free(pFileBuffer);

	return;
}
/*
	* 函数功能：打印所有节信息
	* 参数说明：filename：文件名
	* 返回值：无
	*
	*/
void showSection(const char* fileName)
{
	LPVOID pFileBuffer = NULL;
	LoadFile(fileName, &pFileBuffer);
	PIMAGE_SECTION_HEADER pSectionHeader = NULL;
	if (pFileBuffer == NULL)
	{
		printf("cannot load file");
		return;
	}

	PIMAGE_NT_HEADERS pNtHeader = NULL;
	PIMAGE_DOS_HEADER pDosHeader = NULL;

	pDosHeader = (PIMAGE_DOS_HEADER)pFileBuffer;
	pNtHeader = (PIMAGE_NT_HEADERS)(pDosHeader->e_lfanew + (BYTE*)pFileBuffer);
	if (pNtHeader->Signature != IMAGE_NT_SIGNATURE)
	{
		printf("不是标准的PE文件");
		return;
	}

	printf("*******Section *********\n");
	WORD sectionNum = pNtHeader->FileHeader.NumberOfSections;
	LPVOID base = (LPVOID)(pDosHeader->e_lfanew + sizeof(DWORD) + (BYTE*)pFileBuffer + sizeof(_IMAGE_FILE_HEADER)\
		+ pNtHeader->FileHeader.SizeOfOptionalHeader);

	for (size_t i = 0; i < sectionNum; i++)
	{
		LPVOID nowSection = (LPVOID)((BYTE*)base + i * sizeof(_IMAGE_SECTION_HEADER));
		pSectionHeader = (PIMAGE_SECTION_HEADER)nowSection;
		printf("*******Section %u*********\n", i);

		printf("name:");
		for (size_t i = 0; i < 8; i++)
		{
			printf("%c", pSectionHeader->Name[i]);
		}
		printf("\n");
		printf("VirtualAddress:%x\n", pSectionHeader->VirtualAddress);
		printf("PointerToRawData:%x\n", pSectionHeader->PointerToRawData);
		printf("MISC:%x\n", pSectionHeader->Misc.VirtualSize);
		printf("SizeOfRawData:%x\n", pSectionHeader->SizeOfRawData);

	}
	free(pFileBuffer);
	printf("END SECTION");
	return;
}
/*
	* 函数功能：寻找DOS头
	* 参数说明：pFileBuffer：文件缓冲指针
	* 返回值：DOS头指针
	*注意：无
	*/
PIMAGE_DOS_HEADER FileToDosHeader(LPVOID pFileBuffer)
{
	PIMAGE_DOS_HEADER pDosHeader = NULL;
	if (pFileBuffer == NULL)
	{
		printf("不接受NULL");
		return NULL;
	}
	//检测MZ头
	if (*((WORD*)pFileBuffer) != IMAGE_DOS_SIGNATURE)
	{
		printf("不是标准MZ头！");
		return NULL;
	}
	pDosHeader = (PIMAGE_DOS_HEADER)pFileBuffer;
	return pDosHeader;
}



/*
函数功能：接受文件缓冲区指针，返回NT头指针
参数：文件缓冲区指针
返回值：如果鉴别出符合标准PE文件，返回NT头，否则返回NULL
注意：无
*/
PIMAGE_NT_HEADERS FileToNtHeader(LPVOID pFileBuffer)
{
	PIMAGE_DOS_HEADER pDosHeader = NULL;
	PIMAGE_NT_HEADERS pNtHeaders = NULL;
	if (pFileBuffer == NULL)
	{
		printf("FileToNtHeader函数不接受NULL");
		return NULL;
	}
	//检测MZ头
	if (*((WORD*)pFileBuffer) != IMAGE_DOS_SIGNATURE)
	{
		printf("不是标准MZ头！");
		return NULL;
	}
	pDosHeader = (PIMAGE_DOS_HEADER)pFileBuffer;
	//检测PE签名
	if (*(DWORD*)(pDosHeader->e_lfanew + (BYTE*)pFileBuffer) != IMAGE_NT_SIGNATURE)
	{
		printf("不是标准NT头！");
		return NULL;
	}
	pNtHeaders = (PIMAGE_NT_HEADERS)(pDosHeader->e_lfanew + (BYTE*)pFileBuffer);
	return pNtHeaders;
}
/*
函数功能：接受文件缓冲区指针，返回第一个节表的地址
参数：文件缓冲区指针
返回值：如果鉴别出符合标准PE文件，返回第一个节表的地址，否则返回NULL
注意：无
*/
PIMAGE_SECTION_HEADER LocateSectionBase(LPVOID pFileBuffer)
{
	PIMAGE_DOS_HEADER pDosHeader = NULL;
	PIMAGE_NT_HEADERS pNtHeaders = NULL;
	PIMAGE_SECTION_HEADER pSectionHeaderBase = NULL;
	if (pFileBuffer == NULL)
	{
		printf("不接受NULL");
		return NULL;
	}
	//检测MZ头
	if (*((WORD*)pFileBuffer) != IMAGE_DOS_SIGNATURE)
	{
		printf("不是标准MZ头！");
		return NULL;
	}
	pDosHeader = (PIMAGE_DOS_HEADER)pFileBuffer;
	//检测PE签名
	if (*(DWORD*)(pDosHeader->e_lfanew + (BYTE*)pFileBuffer) != IMAGE_NT_SIGNATURE)
	{
		printf("不是标准NT头！");
		return NULL;
	}
	pNtHeaders = (PIMAGE_NT_HEADERS)(pDosHeader->e_lfanew + (BYTE*)pFileBuffer);
	/*
	pSectionHeaderBase = (PIMAGE_SECTION_HEADER)((BYTE*)pFileBuffer + pDosHeader->e_lfanew + sizeof(DWORD)\
		+ sizeof(IMAGE_FILE_HEADER) + pNtHeaders->FileHeader.SizeOfOptionalHeader); //第一个节表指针地址=文件地址+dos头的e_lfnew偏移+PE标志位+PE头大小+可选头大小（NT头的SizeOfOptionalHeader
	*/
	pSectionHeaderBase = (PIMAGE_SECTION_HEADER)((DWORD)pFileBuffer + pDosHeader->e_lfanew + sizeof(DWORD)\
		+ sizeof(IMAGE_FILE_HEADER) + pNtHeaders->FileHeader.SizeOfOptionalHeader); //第一个节表指针地址=文件地址+dos头的e_lfnew偏移+PE标志位+PE头大小+可选头大小（NT头的SizeOfOptionalHeader
	return pSectionHeaderBase;
}





/*
 函数功能：FileBufferToImageBuffer
参数说明：pFileBuffer：文件缓冲指针
返回值：内存映像指针
注意：用完记得free（）哦
*/
LPVOID FileBufferToImageBuffer(LPVOID pFileBuffer)
{
	DWORD SizeOfImage = 0;
	DWORD SizeOfHeaders = 0;
	WORD NumberOfSections = 0;
	PIMAGE_SECTION_HEADER pSectionHeaderBase = NULL;
	PIMAGE_NT_HEADERS pNtHeaders = NULL;
	LPVOID pImageBuffer = NULL;

	if (pFileBuffer == NULL)
	{
		printf("cannot transform NULL\n");
		return NULL;
	}
	pNtHeaders = FileToNtHeader(pFileBuffer);
	if (pNtHeaders == NULL)
	{
		printf("NT头为空！\n");
		return NULL;
	}
	SizeOfImage = pNtHeaders->OptionalHeader.SizeOfImage;  //获取占用内存大小
	SizeOfHeaders = pNtHeaders->OptionalHeader.SizeOfHeaders;  //获取头大小
	NumberOfSections = pNtHeaders->FileHeader.NumberOfSections; //获取节大小
	pSectionHeaderBase = LocateSectionBase(pFileBuffer); //获取第一个节表位置 
														 //第一个节表地址=文件地址+dos头的e_lfnew偏移+PE标志位+PE头大小+可选头大小（NT头的SizeOfOptionalHeader

	pImageBuffer = malloc(SizeOfImage);
	if (pImageBuffer == NULL)
	{
		printf("cannot malloc memory");
		return NULL;
	}

	memset(pImageBuffer, 0, SizeOfImage);
	memcpy(pImageBuffer, pFileBuffer, SizeOfHeaders);//先把文件头放在内存中

	for (size_t i = 0; i < NumberOfSections; i++)
	{
		PIMAGE_SECTION_HEADER pSectionHeader = (PIMAGE_SECTION_HEADER)\
			((BYTE*)pSectionHeaderBase + sizeof(IMAGE_SECTION_HEADER) * i);//节表大小*第几个节表
		memcpy((BYTE*)pImageBuffer + pSectionHeader->VirtualAddress,
			(BYTE*)pFileBuffer + pSectionHeader->PointerToRawData,
			pSectionHeader->SizeOfRawData);
	}
	return pImageBuffer;
}
bool textbycmp(BYTE a[], BYTE b[], int i)
{
	int x = 0;
	for (int x = 0; x < i; x++)
	{
		if (a[x] != b[x])
		{
			return false;
		}
		x++;
	}
	return true;
}
/*
函数功能：ImageBufferToFileBuffer
参数说明：pImageBuffer：内存映像指针
返回值：pFileBuffer
注意：记得free（）哦
*/
LPVOID ImageBufferToFileBuffer(LPVOID pImageBuffer)
{
	PIMAGE_NT_HEADERS pNtHeaders = FileToNtHeader(pImageBuffer);
	DWORD FileSize = 0;
	PIMAGE_SECTION_HEADER SectionBase = NULL;
	DWORD NumberOfSections = 0;
	if (pNtHeaders == NULL)
	{
		printf("error");
		exit(0);
	}
	SectionBase = LocateSectionBase(pImageBuffer);//计算的第一个节表的大小
	NumberOfSections = pNtHeaders->FileHeader.NumberOfSections;
	PIMAGE_SECTION_HEADER pLastSection = (PIMAGE_SECTION_HEADER)\
		((BYTE*)SectionBase + (NumberOfSections - 1) * sizeof(IMAGE_SECTION_HEADER));
	FileSize = pLastSection->SizeOfRawData + pLastSection->PointerToRawData;  //获取文件大小=最后一个节的大小（节在文件中大小）+文件偏移（pointertorawdata）
	LPVOID pFileBuffer = malloc(FileSize);
	if (pFileBuffer == NULL)
	{
		printf("cannot malloc");
		return NULL;
	}
	memset(pFileBuffer, 0, FileSize);
	memcpy(pFileBuffer, pImageBuffer, pNtHeaders->OptionalHeader.SizeOfHeaders);//拷贝pe文件头


	BYTE bsste[] = {
		0x2E,0x74,0x65,0x78,0x74,0x62,0x73,0x73
	};
	for (size_t i = 0; i < NumberOfSections; i++)
	{
		PIMAGE_SECTION_HEADER pSectionHeader = (PIMAGE_SECTION_HEADER)\
			((BYTE*)SectionBase + i * sizeof(IMAGE_SECTION_HEADER));
		BYTE sectionhe[8] = {};
		memcpy(sectionhe, pSectionHeader->Name, sizeof(pSectionHeader->Name));//跳过textbss节
		//sectionhe = (pSectionHeader->Name);
		if (!textbycmp(sectionhe, bsste, 8)) {
			memcpy((BYTE*)pFileBuffer + pSectionHeader->PointerToRawData,
				(BYTE*)pImageBuffer + pSectionHeader->VirtualAddress,
				pSectionHeader->SizeOfRawData);//从内存偏移的地方拷贝文件对齐的大小到原来文件中的节的位置
		}

	}


	return pFileBuffer;

}
/*
函数功能：返回文件大小
参数：文件缓冲指针，将保存文件的绝对地址，文件大小
返回值：无
注意：无
*/
DWORD FileSizeget(LPVOID pImageBuffer) {
	PIMAGE_NT_HEADERS pNtHeaders = FileToNtHeader(pImageBuffer);
	DWORD FileSize = 0;
	PIMAGE_SECTION_HEADER SectionBase = NULL;
	DWORD NumberOfSections = 0;
	if (pNtHeaders == NULL)
	{
		printf("error");
		exit(0);
	}
	SectionBase = LocateSectionBase(pImageBuffer);//计算的第一个节表的大小
	NumberOfSections = pNtHeaders->FileHeader.NumberOfSections;
	PIMAGE_SECTION_HEADER pLastSection = (PIMAGE_SECTION_HEADER)\
		((BYTE*)SectionBase + (NumberOfSections - 1) * sizeof(IMAGE_SECTION_HEADER));
	FileSize = pLastSection->SizeOfRawData + pLastSection->PointerToRawData;  //获取文件大小=最后一个节的大小（节在文件中大小）+文件偏移（pointertorawdata）

	return FileSize;

}
/*
函数功能：从pFilBuffer指向的地址开始，FileSize大小的数据保存于str指定的绝对地址中
参数：文件缓冲指针，将保存文件的绝对地址，文件大小
返回值：无
注意：无
*/
void SaveFile(LPVOID pFileBuffer, const char* str, DWORD FileSize)
{
	FILE* fp;
	fopen_s(&fp, str, "wb");
	if (fp == NULL)
	{
		printf("cannot open %s", str);
		return;
	}
	fwrite(pFileBuffer, FileSize, 1, fp);
	if (fclose(fp) != 0)
	{
		printf("cannot close %s", str);
		return;
	}
	return;
}
/*
功能：任意文件写入shellcode
接受imagebuffer
返回修改后的imagebuffer
*/
LPVOID changeimagebuffer(LPVOID imagebuffer) {
	PIMAGE_DOS_HEADER pDosHeader = NULL;
	DWORD SizeOfImage = 0;
	DWORD SizeOfHeaders = 0;
	WORD NumberOfSections = 0;
	PIMAGE_SECTION_HEADER pSectionHeaderBase = NULL;
	PIMAGE_NT_HEADERS pNtHeaders = NULL;
	LPVOID pImageBuffer = NULL;
	PBYTE codebegin = NULL;



	pDosHeader = (PIMAGE_DOS_HEADER)imagebuffer;
	pNtHeaders = FileToNtHeader(imagebuffer);

	//判断空闲区是否能存储shellcode代码(文件对齐大小-misc里真实内存大小）
	pSectionHeaderBase = (PIMAGE_SECTION_HEADER)((DWORD)LocateSectionBase(imagebuffer));
	pSectionHeaderBase = (PIMAGE_SECTION_HEADER)((DWORD)pSectionHeaderBase + 0x28);//这里写第二个节表是为了测试vs编译的程序嫩否注入（因为第一个节是textbss段）
	if (((pSectionHeaderBase->SizeOfRawData) - (pSectionHeaderBase->Misc.VirtualSize)) < sizeof(shellcode))
	{
		printf("代码空闲区不足");
		free(imagebuffer);
		return NULL;
	}

	//把代码复制到空闲区
	codebegin = (PBYTE)((DWORD)imagebuffer + pSectionHeaderBase->VirtualAddress + pSectionHeaderBase->Misc.VirtualSize);
	memcpy(codebegin, shellcode, sizeof(shellcode));
	//修正E8

	DWORD e8addr = (DWORD)(MESSAGE_BOX_ADDRESS - (pNtHeaders->OptionalHeader.ImageBase + ((DWORD)codebegin + (DWORD)0x0D - (DWORD)imagebuffer)));
	//e8addr = 0x7D8A55E1;
	*(PDWORD)(codebegin + 9) = e8addr;
	// 修正E9
	DWORD e9addr = (DWORD)((pNtHeaders->OptionalHeader.ImageBase + pNtHeaders->OptionalHeader.AddressOfEntryPoint) - (pNtHeaders->OptionalHeader.ImageBase + ((DWORD)codebegin + (DWORD)0x12 - (DWORD)imagebuffer)));
	//e9addr = 0xFFFFDC95;
	*(PDWORD)(codebegin + 0xE) = e9addr;
	//pSectionHeaderBase = (PIMAGE_SECTION_HEADER)(BYTE*)imagebuffer + pDosHeader->e_lfanew + sizeof(IMAGE_); 

	pNtHeaders->OptionalHeader.AddressOfEntryPoint = (DWORD)codebegin - (DWORD)imagebuffer;
	//pNtHeaders->OptionalHeader.AddressOfEntryPoint = 0x01A730;
	return imagebuffer;


}
/*
函数功能：新增节
参数：内存映像指针
返回值：内存映像指针
注意：无
*/
LPVOID NEWSetion(LPVOID pImageBuffer) {
	/*
1)添加一个新的节(可以copy一份)
2)在新增节后面填充一个节大小的000
3)修改PE头中节的数量
4)修改sizeofimage的大小
5)再原有数据的最后，新增一个节的数据(内存对齐的整数倍).
6)修正新增节表的属性

注意：SizeOfHeader - (DOS +垃圾数据+ PE标记+标准PE头+可选PE头+己存在节表)= 2个节表的大小

空间不够可以把PE头往上移动（占DOS头的垃圾数据）
	
	*/
	PIMAGE_DOS_HEADER pDosHeader = NULL;
	DWORD SizeOfImage = 0;
	DWORD SizeOfHeaders = 0;
	WORD NumberOfSections = 0;
	DWORD pointtonew = 0;
	PIMAGE_SECTION_HEADER pSectionHeaderBase = NULL;
	PIMAGE_SECTION_HEADER pnewSectionHeaderBase = NULL;
	PIMAGE_NT_HEADERS pNtHeaders = NULL;
	//LPVOID pImageBuffer = NULL;
	PBYTE codebegin = NULL;


	pDosHeader = (PIMAGE_DOS_HEADER)pImageBuffer;//dos头
	pNtHeaders = FileToNtHeader(pImageBuffer);//nt头
	
	//验证剩余空间是否够2个节表大小
	DWORD freesp = pNtHeaders->OptionalHeader.SizeOfHeaders - (pDosHeader->e_lfanew + 0x4 + 0x14 + pNtHeaders->FileHeader.SizeOfOptionalHeader + (pNtHeaders->FileHeader.NumberOfSections * 0x28));
	if (freesp < 0x28 * 2)
	{
		printf ("空间不足够添加节表，添加失败");
		return pImageBuffer;
	};


	//找最后一个节表结束的位置添加节
	pSectionHeaderBase = LocateSectionBase(pImageBuffer);
	LPVOID addsectionstart = (BYTE*)pSectionHeaderBase + (DWORD)(0x28 * (pNtHeaders->FileHeader.NumberOfSections));
	memcpy(addsectionstart, pSectionHeaderBase, 0x28);

	//在内存最后添加一个内存对齐整数倍的00
	LPVOID endexe = (BYTE*)pImageBuffer + pNtHeaders->OptionalHeader.SizeOfImage ;
	//内存对齐大小
	const DWORD size = pNtHeaders->OptionalHeader.SectionAlignment;

	BYTE* tian1 = new BYTE[size];
	memset(tian1, 0x00,  size);

	//tian1  
	//BYTE tian[4096] = { 0x00 };
	memcpy(endexe, tian1 , size);

	//修改sizeofimage大小
	pNtHeaders->OptionalHeader.SizeOfImage = pNtHeaders->OptionalHeader.SizeOfImage + size;

	//修改新添加节的属性
	pnewSectionHeaderBase =(PIMAGE_SECTION_HEADER) addsectionstart;
	pnewSectionHeaderBase->Misc.VirtualSize = size;
	pnewSectionHeaderBase->VirtualAddress = (DWORD) endexe - (DWORD) pImageBuffer;
	pnewSectionHeaderBase->SizeOfRawData = size;
	//文件中偏移,先找上一个节的文件偏移+是一个节的大小（偷懒直接看是不是SizeOfRawData打过真实大小，直接加了）
	PIMAGE_SECTION_HEADER presec = PIMAGE_SECTION_HEADER((BYTE*)pnewSectionHeaderBase - 0x28);
	if (presec->SizeOfRawData > presec->Misc.VirtualSize)
	{
		pointtonew = presec->SizeOfRawData + presec->PointerToRawData;
	}
	else
	{
		return 0;
	}
	pnewSectionHeaderBase->PointerToRawData = pointtonew;



	//+pNtHeaders->OptionalHeader.SectionAlignment
	//修改节的数量+1
	pNtHeaders->FileHeader.NumberOfSections = pNtHeaders->FileHeader.NumberOfSections + 1;



	return pImageBuffer;
}

